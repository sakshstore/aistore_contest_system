=== Aistore Contest System ===
Contributors: susheelhbti
Donate link: http://www.aistore2030.com/
Tags: Contest System 
License: GPLv2
Requires at least:  5.3
Tested up to: 5.6
Stable tag: 4.8.0
Requires PHP: 7.0
Version : 1.0

Aistore Contest System allow user to start logo or graphic design contest from their website.




== Description ==

1   Contest System


Logo requirement need a lot of artist skills and if we hire directly a designer then their in surity that his/her design will be good or not we may not like the design.

Using the contest we can allow user to publish their logo design requirement and once admin approve designer can start do design and if the client like they can purchase this.




Remember 

After enableing the plugin you need to create pages with following shortcodes

[contest_list]  This will show all list of contest published on the portal so create a page and add this short code
 

 

== Installation ==

1. Download and extract   to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. "Dashboard"->"Settings"->"Saksh Escrow System"
4. There are some examples on the settings page,  


== Changelog ==

= 1.0.0 =
 

* First release. 

